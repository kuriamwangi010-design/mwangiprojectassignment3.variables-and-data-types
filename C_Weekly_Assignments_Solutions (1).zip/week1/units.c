/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* units.c - Displays the academic units offered this semester */
#include <stdio.h>

int main(void)
{
    printf("Units Offered This Semester:\n");
    printf("1. Introduction to Programming\n");
    printf("2. Data Structures\n");
    printf("3. Computer Networks\n");
    printf("4. Database Systems\n");
    printf("5. Software Engineering\n");
    return 0;
}
