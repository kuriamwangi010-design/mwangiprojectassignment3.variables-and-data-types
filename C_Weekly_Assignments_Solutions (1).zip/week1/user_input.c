/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* user_input.c - Reads height, bank balance and phone number, then displays them */
#include <stdio.h>

int main(void)
{
    float height;          /* height in meters */
    double balance;        /* bank balance in KES */
    char phone[20];        /* phone number kept as a string so the leading 0 is not lost */

    printf("Enter your height (in meters): ");
    scanf("%f", &height);

    printf("Enter your bank balance (KES): ");
    scanf("%lf", &balance);

    printf("Enter your phone number: ");
    scanf("%19s", phone);

    printf("\n----- Your Details -----\n");
    printf("Height       : %.2f m\n", height);
    printf("Bank balance : KES %.2f\n", balance);
    printf("Phone number : %s\n", phone);
    return 0;
}
