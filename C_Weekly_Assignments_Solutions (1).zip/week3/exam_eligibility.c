/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* exam_eligibility.c - Eligible if attendance >= 75 AND average marks >= 40 */
#include <stdio.h>

int main(void)
{
    float attendance, average;

    printf("Enter attendance (%%): ");
    scanf("%f", &attendance);
    printf("Enter average marks: ");
    scanf("%f", &average);

    if (attendance >= 75 && average >= 40)
        printf("Eligible\n");
    else
        printf("Not eligible\n");
    return 0;
}
