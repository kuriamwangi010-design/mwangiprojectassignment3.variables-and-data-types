/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* water_bill.c - Tiered water bill:
   first 30 units @ 20, next 30 units (31-60) @ 25, above 60 @ 30 */
#include <stdio.h>

int main(void)
{
    int units;
    double bill;

    printf("Enter water units consumed: ");
    scanf("%d", &units);

    if (units <= 30)
        bill = units * 20.0;
    else if (units <= 60)
        bill = 30 * 20.0 + (units - 30) * 25.0;
    else
        bill = 30 * 20.0 + 30 * 25.0 + (units - 60) * 30.0;

    printf("Total water bill: %.2f KES\n", bill);
    return 0;
}
