/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* payroll.c - Employee payroll using an array of structures */
#include <stdio.h>
#include <string.h>

#define SIZE 3

/* (i) Employee structure */
struct Employee {
    char id[10];
    char name[40];
    char department[20];
    double basicSalary;
    double allowance;
};

/* (ii) Gross Salary = Basic Salary + Allowance */
double calculateGrossSalary(struct Employee e)
{
    return e.basicSalary + e.allowance;
}

/* Formats a number with thousands separators and 2 decimals, e.g. 58000 -> 58,000.00 */
void formatMoney(double value, char *out)
{
    char tmp[40];
    int len, i, j = 0;
    char *dot;

    sprintf(tmp, "%.2f", value);
    dot = strchr(tmp, '.');
    len = (int) (dot - tmp);
    for (i = 0; i < len; i++) {
        if (i > 0 && (len - i) % 3 == 0)
            out[j++] = ',';
        out[j++] = tmp[i];
    }
    strcpy(out + j, dot);
}

int main(void)
{
    struct Employee emp[SIZE];              /* (iii) array of three employees */
    char gross[40];
    int i;

    /* (iv) read details with a loop */
    for (i = 0; i < SIZE; i++) {
        printf("\nEmployee %d\n", i + 1);
        printf("Enter Employee ID: ");
        scanf("%9s", emp[i].id);
        getchar();
        printf("Enter Employee Name: ");
        fgets(emp[i].name, sizeof(emp[i].name), stdin);
        emp[i].name[strcspn(emp[i].name, "\n")] = '\0';
        printf("Enter Department: ");
        scanf("%19s", emp[i].department);
        printf("Enter Basic Salary: ");
        scanf("%lf", &emp[i].basicSalary);
        printf("Enter Allowance: ");
        scanf("%lf", &emp[i].allowance);
    }

    /* (v) display the report with another loop */
    printf("\n---------------------------------------------------------------\n");
    printf(" EMPLOYEE PAYROLL REPORT\n");
    printf("---------------------------------------------------------------\n");
    printf("%-8s%-22s%-14s%s\n", "ID", "Name", "Department", "Gross Salary (Ksh)");
    printf("---------------------------------------------------------------\n");
    for (i = 0; i < SIZE; i++) {
        formatMoney(calculateGrossSalary(emp[i]), gross);
        printf("%-8s%-22s%-14s%s\n", emp[i].id, emp[i].name, emp[i].department, gross);
    }
    printf("---------------------------------------------------------------\n");
    return 0;
}
