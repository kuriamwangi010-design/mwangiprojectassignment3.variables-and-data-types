/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* vehicle.c - Vehicle registration report using a structure */
#include <stdio.h>
#include <string.h>

/* (a) structure definition */
struct Vehicle {
    char regNo[15];
    char model[30];
    char manufacturer[30];
    int year;
    double dailyCharge;
};

/* Formats a whole number with thousands separators, e.g. 4500 -> 4,500 */
void formatMoney(long value, char *out)
{
    char tmp[32];
    int len, i, j = 0;

    sprintf(tmp, "%ld", value);
    len = (int) strlen(tmp);
    for (i = 0; i < len; i++) {
        if (i > 0 && (len - i) % 3 == 0)
            out[j++] = ',';
        out[j++] = tmp[i];
    }
    out[j] = '\0';
}

int main(void)
{
    struct Vehicle v;                       /* (b) declare a Vehicle variable */
    char fee[32];

    /* (c) read the details */
    printf("Enter Registration Number: ");
    fgets(v.regNo, sizeof(v.regNo), stdin);
    v.regNo[strcspn(v.regNo, "\n")] = '\0';
    printf("Enter Vehicle Model: ");
    fgets(v.model, sizeof(v.model), stdin);
    v.model[strcspn(v.model, "\n")] = '\0';
    printf("Enter Manufacturer: ");
    fgets(v.manufacturer, sizeof(v.manufacturer), stdin);
    v.manufacturer[strcspn(v.manufacturer, "\n")] = '\0';
    printf("Enter Year of Manufacture: ");
    scanf("%d", &v.year);
    printf("Enter Daily Rental Charge (Ksh): ");
    scanf("%lf", &v.dailyCharge);

    formatMoney((long) v.dailyCharge, fee);

    /* (d) display the report */
    printf("\n---------------------------------------------\n");
    printf(" VEHICLE REGISTRATION REPORT\n");
    printf("---------------------------------------------\n");
    printf("Registration No.  : %s\n", v.regNo);
    printf("Vehicle Model     : %s\n", v.model);
    printf("Manufacturer      : %s\n", v.manufacturer);
    printf("Year Manufactured : %d\n", v.year);
    printf("Daily Rental Fee  : Ksh %s\n", fee);
    printf("---------------------------------------------\n");
    return 0;
}
