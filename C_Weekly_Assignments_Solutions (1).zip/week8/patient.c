/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* patient.c - Patient admission report using a structure */
#include <stdio.h>
#include <string.h>

struct Patient {
    char id[15];
    char name[50];
    int age;
    char gender[10];
    char diagnosis[50];
    int daysAdmitted;
};

int main(void)
{
    struct Patient p;

    printf("Enter Patient ID: ");
    scanf("%14s", p.id);
    getchar();
    printf("Enter Patient Name: ");
    fgets(p.name, sizeof(p.name), stdin);
    p.name[strcspn(p.name, "\n")] = '\0';
    printf("Enter Age: ");
    scanf("%d", &p.age);
    printf("Enter Gender: ");
    scanf("%9s", p.gender);
    getchar();
    printf("Enter Diagnosis: ");
    fgets(p.diagnosis, sizeof(p.diagnosis), stdin);
    p.diagnosis[strcspn(p.diagnosis, "\n")] = '\0';
    printf("Enter Number of Days Admitted: ");
    scanf("%d", &p.daysAdmitted);

    printf("\n---------------------------------------\n");
    printf(" PATIENT ADMISSION REPORT\n");
    printf("---------------------------------------\n");
    printf("Patient ID    : %s\n", p.id);
    printf("Patient Name  : %s\n", p.name);
    printf("Age           : %d\n", p.age);
    printf("Gender        : %s\n", p.gender);
    printf("Diagnosis     : %s\n", p.diagnosis);
    printf("Days Admitted : %d\n", p.daysAdmitted);
    return 0;
}
