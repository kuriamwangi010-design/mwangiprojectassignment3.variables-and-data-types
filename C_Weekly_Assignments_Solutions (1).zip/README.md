# Name: KURIA ERNEST MWANGI
# Reg Number: CT100/G/30614/26

# C Weekly Assignments

Compile any program with: gcc -Wall -o name file.c   (add -lm for week2/compound_interest.c)

Week 8 written answers

Vehicle (e) Two applications of structures in C:
1. Storing records of related data of different types under one name, e.g. a student, patient or vehicle record.
2. Building larger data structures such as linked lists, stacks, queues and trees, and passing grouped data to functions.

Payroll (vi) Two advantages of an array of structures over individual variables:
1. One loop can read, process and display every record, so the code is shorter and easier to maintain.
2. It is easy to scale: adding more employees only means changing the array size, not declaring new variables.
