/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* total_sales.c - Read amounts from sales.txt and display the day's total */
#include <stdio.h>

int main(void)
{
    FILE *fp;
    double amount, total = 0;

    fp = fopen("sales.txt", "r");
    if (fp == NULL) {
        printf("Error: could not open sales.txt\n");
        return 1;
    }

    while (fscanf(fp, "%lf", &amount) == 1)
        total += amount;

    fclose(fp);                              /* always close the file */

    printf("Total sales for the day: %.2f\n", total);
    return 0;
}
