/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* borrowed_books.c - Append book titles to borrowed_books.txt without deleting old records */
#include <stdio.h>
#include <string.h>

int main(void)
{
    FILE *fp;
    char title[100];

    fp = fopen("borrowed_books.txt", "a");   /* "a" = append mode keeps existing records */
    if (fp == NULL) {
        printf("Error: could not open file.\n");
        return 1;
    }

    printf("Enter the book title: ");
    fgets(title, sizeof(title), stdin);
    title[strcspn(title, "\n")] = '\0';      /* remove the newline */

    fprintf(fp, "%s\n", title);
    fclose(fp);

    printf("Title \"%s\" stored successfully.\n", title);
    return 0;
}
