/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* read_results.c - Read student records from the binary file results.dat */
#include <stdio.h>

struct Student {
    char name[50];
    char regNo[20];
    float totalMarks;
};

int main(void)
{
    FILE *fp;
    struct Student s;

    fp = fopen("results.dat", "rb");        /* rb = read binary */
    if (fp == NULL) {
        printf("Error: could not open results.dat\n");
        return 1;
    }

    printf("%-25s %s\n", "Name", "Marks");
    printf("------------------------------------\n");
    while (fread(&s, sizeof(struct Student), 1, fp) == 1)
        printf("%-25s %.1f\n", s.name, s.totalMarks);

    fclose(fp);
    return 0;
}
