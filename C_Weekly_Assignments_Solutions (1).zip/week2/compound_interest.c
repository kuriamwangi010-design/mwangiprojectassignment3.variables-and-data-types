/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* compound_interest.c - CI = P(1 + r/100)^t - P   (compile with -lm) */
#include <stdio.h>
#include <math.h>

int main(void)
{
    double principal, time, rate, amount, ci;

    printf("Enter the principal amount: ");
    scanf("%lf", &principal);
    printf("Enter the time (years): ");
    scanf("%lf", &time);
    printf("Enter the rate (%%): ");
    scanf("%lf", &rate);

    amount = principal * pow(1 + rate / 100, time);
    ci = amount - principal;

    printf("Total amount      = %.2f\n", amount);
    printf("Compound interest = %.2f\n", ci);
    return 0;
}
