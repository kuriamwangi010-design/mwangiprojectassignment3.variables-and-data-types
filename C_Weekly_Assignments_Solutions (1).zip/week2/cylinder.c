/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* cylinder.c - Volume and surface area of a cylinder */
#include <stdio.h>

#define PI 3.14159265358979

int main(void)
{
    double r, h, volume, surface;

    printf("Enter the radius of the cylinder: ");
    scanf("%lf", &r);
    printf("Enter the height of the cylinder: ");
    scanf("%lf", &h);

    volume  = PI * r * r * h;                  /* V = pi r^2 h */
    surface = 2 * PI * r * r + 2 * PI * r * h; /* A = 2 pi r^2 + 2 pi r h */

    printf("Volume       = %.2f\n", volume);
    printf("Surface area = %.2f\n", surface);
    return 0;
}
