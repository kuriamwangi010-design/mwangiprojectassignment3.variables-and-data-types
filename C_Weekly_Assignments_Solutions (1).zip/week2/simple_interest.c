/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* simple_interest.c - SI = (principal * time * rate) / 100 */
#include <stdio.h>

int main(void)
{
    double principal, time, rate, si;

    printf("Enter the principal amount: ");
    scanf("%lf", &principal);
    printf("Enter the time (years): ");
    scanf("%lf", &time);
    printf("Enter the rate (%%): ");
    scanf("%lf", &rate);

    si = (principal * time * rate) / 100;
    printf("Simple interest = %.2f\n", si);
    return 0;
}
