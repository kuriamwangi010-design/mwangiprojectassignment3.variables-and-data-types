/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* bank_loan.c - Loan eligibility: age >= 21 and annual income >= 21,000 */
#include <stdio.h>

int main(void)
{
    int age;
    double income;

    printf("Enter your age: ");
    scanf("%d", &age);
    printf("Enter your annual income (KSh): ");
    scanf("%lf", &income);

    if (age >= 21 && income >= 21000)
        printf("Congratulations you qualify for a loan.\n");
    else
        printf("Unfortunately, we are unable to offer you a loan at this time.\n");
    return 0;
}
