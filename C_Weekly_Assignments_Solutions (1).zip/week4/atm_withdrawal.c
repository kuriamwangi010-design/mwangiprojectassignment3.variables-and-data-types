/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* atm_withdrawal.c - Withdraw until the balance is zero or negative */
#include <stdio.h>

int main(void)
{
    double balance, amount;

    printf("Enter your starting account balance: ");
    scanf("%lf", &balance);

    while (balance > 0) {
        printf("Enter amount to withdraw: ");
        scanf("%lf", &amount);
        balance = balance - amount;   /* the balance may go to zero or negative */
        printf("Balance after withdrawal: %.2f\n", balance);
    }

    printf("Balance is zero or negative. No more withdrawals allowed.\n");
    return 0;
}
