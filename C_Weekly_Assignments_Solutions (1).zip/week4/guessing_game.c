/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* guessing_game.c - Guess a random number between 1 and 20 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    int secret, guess, attempts = 0;

    srand((unsigned) time(NULL));      /* seed the random generator */
    secret = rand() % 20 + 1;          /* number from 1 to 20 inclusive */

    printf("I have picked a number between 1 and 20. Try to guess it!\n");

    do {
        printf("Enter your guess: ");
        scanf("%d", &guess);
        attempts++;

        if (guess > secret)
            printf("Too high!\n");
        else if (guess < secret)
            printf("Too low!\n");
        else
            printf("Congratulations!\n");
    } while (guess != secret);

    printf("You guessed it in %d attempt(s).\n", attempts);
    return 0;
}
