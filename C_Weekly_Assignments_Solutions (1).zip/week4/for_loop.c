/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* for_loop.c - Prints 100 down to 50, one per line */
#include <stdio.h>

int main(void)
{
    int i;
    for (i = 100; i >= 50; i--)
        printf("%d\n", i);
    return 0;
}
