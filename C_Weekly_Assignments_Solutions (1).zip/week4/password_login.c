/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* password_login.c - Keep asking until the password 1234 is entered */
#include <stdio.h>

int main(void)
{
    int password;

    do {
        printf("Enter password: ");
        scanf("%d", &password);
    } while (password != 1234);

    printf("Access Granted\n");
    return 0;
}
