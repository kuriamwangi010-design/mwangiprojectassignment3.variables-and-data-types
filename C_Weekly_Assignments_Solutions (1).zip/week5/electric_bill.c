/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* electric_bill.c - First 100 units @10, next 100 @15, above 200 @20 */
#include <stdio.h>

double calculateElectricBill(int units)
{
    double bill;

    if (units <= 100)
        bill = units * 10.0;
    else if (units <= 200)
        bill = 100 * 10.0 + (units - 100) * 15.0;
    else
        bill = 100 * 10.0 + 100 * 15.0 + (units - 200) * 20.0;
    return bill;
}

int main(void)
{
    int units;

    printf("Enter units consumed: ");
    scanf("%d", &units);
    printf("Total bill: KSh. %.2f\n", calculateElectricBill(units));
    return 0;
}
