/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* fare.c - Fare at KSh. 50 per kilometre */
#include <stdio.h>

double calculateFare(double distance)
{
    return distance * 50.0;
}

int main(void)
{
    double distance;

    printf("Enter distance travelled (km): ");
    scanf("%lf", &distance);
    printf("Total fare: KSh. %.2f\n", calculateFare(distance));
    return 0;
}
