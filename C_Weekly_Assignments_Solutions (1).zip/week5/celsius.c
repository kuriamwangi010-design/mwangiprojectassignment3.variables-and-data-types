/*
 * Name       : KURIA ERNEST MWANGI
 * Reg Number : CT100/G/30614/26
 */
/* celsius.c - Convert Fahrenheit to Celsius: C = (F - 32) * 5/9 */
#include <stdio.h>

double convertToCelsius(double fahrenheit)
{
    return (fahrenheit - 32) * 5.0 / 9.0;   /* 5.0/9.0 avoids integer division */
}

int main(void)
{
    double f;

    printf("Enter temperature in Fahrenheit: ");
    scanf("%lf", &f);
    printf("Temperature in Celsius: %.1f C\n", convertToCelsius(f));
    return 0;
}
